function dist = ExpD(pre_vec, mtx_vec, wgt_vec)
%ExpD implements the distance computation of exponential loss-based decoding strategy
%Type 'help ExpD' under Matlab prompt for more detailed information
%
%	Syntax
%
%       dist = ExpD(pre_vec, mtx_vec, wgt_vec)
%
%	Description
%
%   ExpD takes,
%       pre_vec     - An 1 x num_ecoc vector, binary prediction vector (-1/+1)
%       mtx_vec     - An 1 x num_ecoc vector, binary/ternary ECOC matrix vector
%       wgt_vec     - An 1 x num_ecoc vector, weighted matrix vector (default: all ones, i.e., no weight matrix are used)
%   and returns,
%       dist	    - The exponential loss (i.e., loss(z) = exp(-z)) between pre_vec and mtx_vec
% NOTE: For ternary encoding, the 0-bits in ECOC matrix are not considered, i.e., attenuated decoding.

    if nargin<3
        wgt_vec = ones(size(mtx_vec));
    end
    dist = sum(abs(mtx_vec).*(wgt_vec.*exp(-pre_vec.*mtx_vec)));
end