function dist = L01D(pre_vec, mtx_vec, wgt_vec)
%L01D implements the distance computation of zero-one loss-based decoding strategy
%Type 'help L01D' under Matlab prompt for more detailed information
%
%	Syntax
%
%       dist = L01D(pre_vec, mtx_vec, wgt_vec)
%
%	Description
%
%   L01D takes,
%       pre_vec     - An 1 x num_ecoc vector, binary prediction vector (-1/+1)
%       mtx_vec     - An 1 x num_ecoc vector, binary/ternary ECOC matrix vector
%       wgt_vec     - An 1 x num_ecoc vector, weighted matrix vector (default: all ones, i.e., no weight matrix are used)
%   and returns,
%       dist	    - The zero-one loss (i.e., loss(z) = 1 if z<0, and 0 otherwise) between pre_vec and mtx_vec
% NOTE: For ternary encoding, the 0-bits in ECOC matrix are not considered, i.e., attenuated decoding.

    if nargin<3
        wgt_vec = ones(size(mtx_vec));
    end
    zero_one_loss = (pre_vec.*mtx_vec<0);
    dist = sum(abs(mtx_vec).*(wgt_vec.*zero_one_loss));
end