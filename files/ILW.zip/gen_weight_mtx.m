function [ weight_mtx_norm ] = gen_weight_mtx( ecoc_mtx, class_set, y_tr_m, yp_tr_b )
%gen_weight_mtx generates the weight matrix as described in [1]
%Type 'help gen_weight_mtx' under Matlab prompt for more detailed information
%
%	Syntax
%
%       [ weight_mtx_norm ] = gen_weight_mtx( ecoc_mtx, class_set, y_tr_m, yp_tr_b )
%
%	Description
%
%   gen_weight_mtx takes,
%       ecoc_mtx        - An N x L matrix, ECOC matrix (-1/+1 or -1/0/+1)
%       class_set       - An N x 1 vector, the set of classes where the j-th item corresponds to the j-th row of ecoc_mtx
%       y_tr_m          - An m x 1 vector, the multi-class label vector for all training samples
%       yp_tr_b         - An m x L matrix, the binary prediction for all training samples
%
%   and returns,
%       weight_mtx_norm - An N x L matrix, the weight matrix
%
%  [1] S. Escalera, O. Pujol, and P. Radeva, On the decoding process in ternary error-correcting output codes, IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 32, no. 1, pp. 120-134, 2010.
    
    [num_class,num_ecoc] = size(ecoc_mtx);
    %weight matrix computation
    weight_mtx = zeros(num_class,num_ecoc);
    for ic=1:num_class
        idx_ic = (y_tr_m==class_set(ic));
        num_sum_ic = sum(idx_ic);
        for ib=1:num_ecoc
            if ecoc_mtx(ic,ib)~=0
                num_ok_ic_ib = sum(yp_tr_b(idx_ic,ib)==ecoc_mtx(ic,ib));
                weight_mtx(ic,ib) = num_ok_ic_ib/num_sum_ic;
            end
        end
    end
    %normalization per row
    sum_row = sum(weight_mtx,2);
    weight_mtx_norm = zeros(num_class,num_ecoc);
    for ic=1:num_class
        if sum_row(ic)>0
            weight_mtx_norm(ic,:) = weight_mtx(ic,:)/sum_row(ic);
        else%if the sum of this row is zero, set average value to non-zero code positions
            idx = (ecoc_mtx(ic,:)~=0);
            weight_mtx_norm(ic,idx) = 1/sum(idx);
        end
    end
end