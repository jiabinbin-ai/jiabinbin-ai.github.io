function [ y_predict ] = Decoding( myDist, yp_test, ecoc_mtx, wgt_mtx, class_set )
%Decoding implements the decoding process in decomposition-based multi-class classification as described in [1]
%Type 'help Decoding' under Matlab prompt for more detailed information about this function
%
%	Syntax
%
%       [ y_predict ] = Decoding( myDist, yp_test, ecoc_mtx, wgt_mtx, class_set )
%
%	Description
%
%   Decoding takes,
%       myDist      - An distance function, e.g., Hamming distance
%       yp_test     - An pxL array, the binary predicted label (+1 or -1) of the i-th testing instance (1<=i<=p) by the j-th binary classifier (1<=j<=L) is stored in yp_test(i,j)
%       ecoc_mtx    - An NxL array, the ECOC matrix
%       wgt_mtx     - An NxLxp array, the instance-specific weight matrix where the weight matrix for i-th testing instance is stored in in wgt_mtx(:,:,i), or NxL array, the general weight matrix
%       class_set   - An Nx1 vector, the set of class labels
%
%   and returns,
%       y_predict  - An px1 array,, the multi-class prediction vector for test set
%
%  [1] B.-B. Jia, J.-Y. Liu, M.-L. Zhang. Instance-specific Loss-weighted Decoding for Decomposition-based Multi-class Classification, IEEE Transactions on Neural Networks and Learning Systems, 2024, in press.

    num_testing = size(yp_test,1);
    num_class = size(ecoc_mtx, 1);
    y_predict = zeros(num_testing,1);
    for itest=1:num_testing
        pre_vec = yp_test(itest,:);
        dist_vec = zeros(num_class,1);
        for iclass=1:num_class
            mtx_vec = ecoc_mtx(iclass,:);
            if length(size(wgt_mtx))>2
                wgt_vec = wgt_mtx(iclass,:,itest);
            else
                wgt_vec = wgt_mtx(iclass,:);
            end
            dist_vec(iclass) = myDist(pre_vec, mtx_vec, wgt_vec);
        end
        idx = find(dist_vec==min(dist_vec));
%         %randomly select one if there are multiple minimum values
%         tmplist = randperm(length(idx));
%         max_idx = idx(tmplist(1));
%         y_predict(itest) = class_set(max_idx);
        %select the first one
        y_predict(itest) = class_set(idx(1));
    end
end

