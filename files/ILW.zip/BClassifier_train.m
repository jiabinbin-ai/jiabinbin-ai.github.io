function [ model ] = BClassifier_train( X_train, y_train )
%BClassifier_train implements the training process of binary classification
%Type 'help BClassifier_train' under Matlab prompt for more detailed information
%
%	Syntax
%
%       [ model ] = BClassifier_train( X_train, y_train )
%
%	Description
%
%   BClassifier_train takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%   and returns,
%       model	    - The predictive model (dependent on specific binary classification algorithm)
%See also BClassifier_test

    %We use liblinear with the setting "L2-regularized logistic regression
    %(primal)" to serve as the base binary classifier. 
    %Other kinds of binary classifers can also be used according to your own needs.
    model = train(y_train,sparse(X_train),'-s 0 -B 1 -R -q');

end