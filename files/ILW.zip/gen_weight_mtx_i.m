function [ weight_mtx_norm ] = gen_weight_mtx_i( ecoc_mtx, class_set, y_tr_m, yp_tr_b, X_tr, X_te, numK )
%gen_weight_mtx_i generates the instance-specific weight matrix as described in [1]
%Type 'help gen_weight_mtx_i' under Matlab prompt for more detailed information about this function
%
%	Syntax
%
%       [ weight_mtx_norm ] = gen_weight_mtx_i( ecoc_mtx, class_set, y_tr_m, yp_tr_b, X_tr, X_te, numK )
%
%	Description
%
%   gen_weight_mtx_i takes,
%       ecoc_mtx        - An N x L matrix, ECOC matrix (-1/+1 or -1/0/+1)
%       class_set       - An N x 1 vector, the set of classes where the j-th item corresponds to the j-th row of ecoc_mtx
%       y_tr_m          - An m x 1 vector, the multi-class label vector for all training samples
%       yp_tr_b         - An m x L matrix, the binary prediction for all training samples
%       X_tr            - An m x d matrix, the training instance matrix
%       X_te            - An p x d matrix, the testing instance matrix
%       numK            - An scalar, the number of nearest neighbors when estimating the accuracy per instance (default: 10)
%
%   and returns,
%       weight_mtx_norm - An N x L x p matrix, the instance-specific weight matrix where the weight matrix for i-th testing instance is stored in in weight_mtx_norm(:,:,i)
%
%  [1] B.-B. Jia, J.-Y. Liu, M.-L. Zhang, Instance-specific loss-weighted decoding for decomposition-based multi-class classification, IEEE Transactions on Neural Networks and Learning Systems, 2024, in press.

    if nargin<7
        numK = 10;
    end
    [num_class,num_ecoc] = size(ecoc_mtx);
    num_tr = size(X_tr,1);
    num_te = size(X_te,1);
    %transform multi-class label vector to binary label matrix w.r.t. ECOC matrix
    y_tr_b = zeros(num_tr,num_ecoc);
    for ic=1:num_class
        idx_ic = (y_tr_m==class_set(ic));
        for ib=1:num_ecoc
            y_tr_b(idx_ic,ib) = ecoc_mtx(ic,ib);
        end
    end
    %weight matrix computation
    weight_mtx = zeros(num_class,num_ecoc,num_te);
    for ib=1:num_ecoc
        idx_ib = (y_tr_b(:,ib)~=0);
        yp_tr_b_ib = yp_tr_b(idx_ib,ib);
        y_tr_b_ib = y_tr_b(idx_ib,ib);
        X_tr_ib = X_tr(idx_ib,:);
        IDX_ib = knnsearch(X_tr_ib,X_te,'K',numK);
        num_tr_ib = size(X_tr_ib,1);
        num_sum_ib = min(num_tr_ib,numK);%for extreme case, the number of training samples might be less than numK
        for itest=1:num_te
            IDX_ib_itest = IDX_ib(itest,:);
            num_ok_ib_itest = sum(yp_tr_b_ib(IDX_ib_itest)==y_tr_b_ib(IDX_ib_itest));
            weight_mtx(ecoc_mtx(:,ib)~=0,ib,itest) = num_ok_ib_itest/num_sum_ib;
        end
    end
    %normalization per row
    weight_mtx_norm = zeros(num_class,num_ecoc,num_te);
    for itest=1:num_te
        sum_row = sum(weight_mtx(:,:,itest),2);
        for ic=1:num_class
            if sum_row(ic)>0
                weight_mtx_norm(ic,:,itest) = weight_mtx(ic,:,itest)/sum_row(ic);
            else%if the sum of this row is zero, set average value to non-zero code positions
                idx = (ecoc_mtx(ic,:)~=0);
                weight_mtx_norm(ic,idx,itest) = 1/sum(idx);
            end
        end
    end
end