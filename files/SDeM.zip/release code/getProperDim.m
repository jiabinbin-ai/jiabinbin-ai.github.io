function proper_dim = getProperDim(lambda, th)
% getProperDim determines the dimensionality of the projected feature space
%
% Syntax
%
%       proper_dim = getProperDim(lambda, th)
%
% Description
%
%       getProperDim takes,
%           lambda           - Derived eigenvalues
%           th               - The threshold which controls the dimensionality of the projected feature space
%
%      and returns,
%           proper_dim       - The dimensionality of the projected feature space
%

if th == 0
    proper_dim = length(lambda);
    return;
end

if th < 1 % use thr
    thr = th;
    sum_lambda = sum(lambda);
    lambda_num = length(lambda);
    tmp_lambda = 0;                
    for lind = 1 : lambda_num
        tmp_lambda = tmp_lambda + lambda(lind);
        if tmp_lambda >= thr * sum_lambda
            proper_dim = lind;
            break;
        end
    end
else % use d
    proper_dim = th;
end