%This is an examplar file on how the SDeM program could be used (The main function is "SDeM.m")
%
%Type 'help SDeM' under Matlab prompt for more detailed information
%
%N.B.: Please ensure that liblinear package [1] (as attached) is put under the matlab path before envoking the following demo.
%
%[1] Rong-En Fan, Kai-Wei Chang, Cho-Jui Hsieh, Xiang-Rui Wang, Chih-Jen Lin: LIBLINEAR: A Library for Large Linear Classification. J. Mach. Learn. Res. 9: 1871-1874 (2008). Software available at https://www.csie.ntu.edu.tw/~cjlin/liblinear/index.html
clear;clc;close all;fclose('all');
%load data set
load('Oes10.mat');
numFolds = 10;
HS = zeros(numFolds,1);EM = HS; SEM = HS;
for numFold=1:numFolds
    disp(['The(',num2str(numFold),'/',num2str(numFolds),')cross-validataion']);
    X_train = data.norm(idx_folds{numFold}.train,:);
    X_test = data.norm(idx_folds{numFold}.test,:);
    y_train = target(idx_folds{numFold}.train,:);    
    y_test = target(idx_folds{numFold}.test,:);

    % Obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end

    %main
    disp('Dimensionality reduction...');
    rdim = min(sum(num_per_dim) - num_dim,num_features);
    W = SDeM(X_train, y_train, rdim);

    disp('Predictive model induction...');%Binary relevance   
    y_predict = zeros(num_testing,num_dim)-inf;
    for dd=1:num_dim
        model_train = train(y_train(:,dd),sparse((X_train*W)),'-s 3 -q');
        [y_predict(:,dd), ~, ~] = predict(y_test(:,dd),sparse((X_test*W)), model_train,'-q');
    end
    HS(numFold) = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    EM(numFold) = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    SEM(numFold) = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);     
end
%disp experimental results
disp('Experimental results:');     
disp([' HS = ', num2str(mean(HS),'%4.3f'), ' �� ', num2str(std(HS),'%4.3f')]);
disp([' EM = ', num2str(mean(EM),'%4.3f'), ' �� ', num2str(std(EM),'%4.3f')]);
disp(['SEM = ', num2str(mean(SEM),'%4.3f'), ' �� ', num2str(std(SEM),'%4.3f')]);
