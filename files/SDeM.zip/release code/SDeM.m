function W = SDeM( X_train, y_train, rdim )
%SDeM implements the SDeM approach as described in [1]
%Type 'help SDeM' under Matlab prompt for more detailed information about SDeM
%
%	Syntax
%
%       W = SDeM( X_train, y_train, rdim )
%
%	Description
%
%   SDeM takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       rdim        - A scalar, the number of retained features d' or the threshold th
%   and returns,
%       W   	    - A dxd' array, the dimensionality reduction mapping matrix
%
%  [1] Jia B-B, Zhang M-L. Supervised dimensionality reduction for multi-dimensional classification (in Chinese). Sci Sin Inform, 2023, 53(12): 2325�C2340, doi: 10.1360/SSI-2022-0363
%

%     %default parameter setting
%     if nargin<5
%         rdim = min(sum(num_per_dim) - num_dim,num_features);
%     end

    %obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_dim = size(y_train,2);%number of dimensions(class variables)
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end
    %label space decomposition
    num_ovr_dim = num_per_dim;
    num_ovr = sum(num_ovr_dim);
    y_train_ovr = zeros(num_training,num_ovr);
    cnt_ovr = 1;
    for dd=1:num_dim
        for aa=1:num_per_dim(dd)
            tmp_y = (y_train(:,dd) == C_per_dim{dd}(aa))+0;
            y_train_ovr(:,cnt_ovr) = tmp_y;
            cnt_ovr = cnt_ovr + 1;
        end
    end

    % dimensionality reduction
    L = y_train_ovr*y_train_ovr';
    H = eye(num_training) - ones(num_training)/num_training;
    S = X_train'*H*L*H*X_train;
    clear L H;
    [tmp_Vec, tmp_lambda] = eig(S);
    tmp_Vec = real(tmp_Vec);
    tmp_lambda = real(diag(tmp_lambda));
    [lambda, order] = sort(tmp_lambda, 'descend');
    W_orig = tmp_Vec(:,order);
    proper_dim = getProperDim(lambda, rdim);
    W = W_orig(:,1:proper_dim);
end