function [ X_train_statistics, X_test_statistics, KNN_train_idx, KNN_test_idx] = KNN_statistics( X_train, y_train, X_test, Num )
%KNN_statistics obtains the KNN statistics for MDC data set
%
%	Syntax
%
%       [ X_train_statistics, X_test_statistics, KNN_train_idx, KNN_test_idx] = KNN_statistics( X_train, y_train, X_test, Num )
%
%	Description
%
%   kNN_statistics takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       Num         - Number of nearest neighbors considered (default 10)
%   and returns,
%       X_train_statistics  - KNN statistics of train set
%       X_test_statistics   - KNN statistics of train set
%       KNN_train_idx       - KNN index of train set
%       KNN_train_idx       - KNN index of test set
%see also KNN_distance_matrix

    %% default parameters setting
    if nargin<4
        Num = 10;
    end
    if nargin<3
        error('Not enough input parameters!');
    end

    %% get parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end

    %% Obtain KNN statistics for training set
    %Obtain kNN Distance Matrix of training data set
    [ ~, dist_idx ] = KNN_distance_matrix(X_train,X_train,Num);
    %KNN statistics of train set
    X_train_statistics = zeros(num_training,sum(num_per_dim));
    for i=1:num_training
        index = dist_idx(i,:);
        for kk=1:Num
            idx_base = 0;
            for dd=1:num_dim
                for ll=1:num_per_dim(dd)
                    if y_train(index(kk),dd)==C_per_dim{dd}(ll)
                        X_train_statistics(i,idx_base+ll)=X_train_statistics(i,idx_base+ll)+1;
                    end
                end
                idx_base = idx_base + num_per_dim(dd);
            end
        end
    end
    KNN_train_idx = dist_idx(:,1:Num);
    %% Obtain KNN statistics for testing instance
    %Obtain kNN Distance Matrix of testing data set
    [ ~, dist_idx ] = KNN_distance_matrix(X_train,X_test,Num);
    %KNN statistics of test set
    X_test_statistics = zeros(num_testing,sum(num_per_dim));
    for i=1:num_testing
        index = dist_idx(i,:);
        for kk=1:Num
            idx_base = 0;
            for dd=1:num_dim
                for ll=1:num_per_dim(dd)
                    if y_train(index(kk),dd)==C_per_dim{dd}(ll)
                        X_test_statistics(i,idx_base+ll)=X_test_statistics(i,idx_base+ll)+1;
                    end
                end
                idx_base = idx_base + num_per_dim(dd);
            end
        end
    end
    KNN_test_idx = dist_idx(:,1:Num);
end

