function [ Eval,y_predict ] = MDKNN_DeV2( X_train, y_train, X_test, y_test, Num )
%MDKNN_DeV2 implements the second degenerated version of MDKNN approach (i.e., DeV2) as described in [1]
%Type 'help MDKNN_DeV2' under Matlab prompt for more detailed information about MDKNN_DeV2
%
%	Syntax
%
%       [ Eval,y_predict ] = MDKNN_DeV2( X_train, y_train, X_test, y_test, Num )
%
%	Description
%
%   MDKNN_DeV2 takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       y_test      - An pxq array, the ith class vector of testing instance is stored in y_test(i,:)
%       Num         - Number of nearest neighbors considered (default 10)
%   and returns,
%       Eval	    - A struct where 
%						Eval.HS correpsonds to the hamming score on testing data as described in [1]
%						Eval.EM correpsonds to the exact match on testing data as described in [1]
%						Eval.SEM correpsonds to the sub-exact match on testing data as described in [1]
%       y_predict	- An pxq array, the predicted class matrix for test instance matrix X_test
%
%  [1] B.-B. Jia, M.-L. Zhang. MD-KNN: An Instance-based Approach for Multi-Dimensional Classification, In: ICPR, 2020.
%
%See also KNN_statistics and KNN_distance_matrix.

    %obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end
    %main function
    [ X_train_statistics, X_test_statistics] = KNN_statistics(X_train, y_train, X_test, Num);
    y_predict = zeros(size(y_test));
    for dd=1:num_dim
        X_train_kNN_dd = X_train_statistics(:,sum(num_per_dim(1:dd-1))+1:sum(num_per_dim(1:dd)));
        X_test_kNN_dd = X_test_statistics(:,sum(num_per_dim(1:dd-1))+1:sum(num_per_dim(1:dd)));
        model_svm = svmtrain(y_train(:,dd),X_train_kNN_dd,'-t 0 -q'); 
        y_predict(:,dd) = svmpredict(y_test(:,dd),X_test_kNN_dd, model_svm,'-q');
    end
    Eval.HS = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    Eval.EM = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    Eval.SEM = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);
end