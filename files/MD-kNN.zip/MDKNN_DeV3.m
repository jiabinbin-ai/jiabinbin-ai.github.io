function [ Eval,y_predict ] = MDKNN_DeV3( X_train, y_train, X_test, y_test, Num )
%MDKNN_DeV3 implements the third degenerated version of MDKNN approach (i.e., DeV3) as described in [1]
%Type 'help MDKNN_DeV3' under Matlab prompt for more detailed information about MDKNN_DeV3
%
%	Syntax
%
%       [ Eval,y_predict ] = MDKNN_DeV3( X_train, y_train, X_test, y_test, Num )
%
%	Description
%
%   MDKNN_DeV3 takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       y_test      - An pxq array, the ith class vector of testing instance is stored in y_test(i,:)
%       Num         - Number of nearest neighbors considered (default 10)
%   and returns,
%       Eval	    - A struct where 
%						Eval.HS correpsonds to the hamming score on testing data as described in [1]
%						Eval.EM correpsonds to the exact match on testing data as described in [1]
%						Eval.SEM correpsonds to the sub-exact match on testing data as described in [1]
%       y_predict	- An pxq array, the predicted class matrix for test instance matrix X_test
%
%  [1] B.-B. Jia, M.-L. Zhang. MD-KNN: An Instance-based Approach for Multi-Dimensional Classification, In: ICPR, 2020.
%
%See also KNN_statistics and KNN_distance_matrix.

    %obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end
    %main function
    [ X_train_statistics, X_test_statistics, KNN_train_idx, KNN_test_idx ] = KNN_statistics(X_train, y_train, X_test, Num);
    y_predict = zeros(size(y_test));
    for dd1=1:num_dim
        X_train_kNN_dd1 = X_train_statistics(:,sum(num_per_dim(1:dd1-1))+1:sum(num_per_dim(1:dd1)));
        X_test_kNN_dd1 = X_test_statistics(:,sum(num_per_dim(1:dd1-1))+1:sum(num_per_dim(1:dd1)));
        dd2_set = setdiff(1:num_dim,dd1);
        y_pre_test_KNN_acc = zeros(num_testing,num_dim-1);
        y_pre_test_all_acc = zeros(1,num_dim-1);
        y_pre_test_pair = zeros(num_testing,num_dim-1);
        for dd2_idx=1:num_dim-1
            dd2 = dd2_set(dd2_idx);
            X_train_kNN_dd2 = X_train_statistics(:,sum(num_per_dim(1:dd2-1))+1:sum(num_per_dim(1:dd2)));
            X_test_kNN_dd2 = X_test_statistics(:,sum(num_per_dim(1:dd2-1))+1:sum(num_per_dim(1:dd2)));
            X_train_pair = [X_train_kNN_dd1,X_train_kNN_dd2];
            X_test_pair = [X_test_kNN_dd1,X_test_kNN_dd2];
            model_svm = svmtrain(y_train(:,dd1),X_train_pair,'-t 0 -q'); 
            y_pre_test_pair(:,dd2_idx) = svmpredict(y_test(:,dd1),X_test_pair, model_svm,'-q');

            y_pre_train_dd = svmpredict(y_train(:,dd1),X_train_pair, model_svm,'-q');
            y_pre_test_all_acc(dd2_idx) = sum(y_pre_train_dd==y_train(:,dd1));%global accuarcy
            y_test_KNN_real = zeros(num_testing,Num);
            y_test_KNN_pre = zeros(num_testing,Num);
            for itest=1:num_testing
                y_test_KNN_pre(itest,:) = y_pre_train_dd(KNN_test_idx(itest,:))';
                y_test_KNN_real(itest,:) = y_train(KNN_test_idx(itest,:),dd1)';
            end
            y_pre_test_KNN_acc(:,dd2_idx) = sum(y_test_KNN_real==y_test_KNN_pre,2);%KNN accuarcy               
        end
        for itest=1:num_testing
            [tempmax,tempidx] = max(y_pre_test_KNN_acc(itest,:));
            index_max = (y_pre_test_KNN_acc(itest,:)==tempmax);
            num_max = sum(index_max);
            if num_max==1%only one maximum
                index = tempidx;
            else%more than one classifier with maximum KNN accuracy
                index_set = 1:num_dim-1;
                index_candidate = index_set(index_max);
                [tempmaxmax,tempmaxidx] = max(y_pre_test_all_acc(index_max));
                index = index_candidate(tempmaxidx);%use the maximum global accuracy instead
            end
            y_predict(itest,dd1) = y_pre_test_pair(itest,index);
        end
    end
    Eval.HS = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    Eval.EM = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    Eval.SEM = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);
end