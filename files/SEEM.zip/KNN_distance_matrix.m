function [ dist_val, dist_idx ] = KNN_distance_matrix( X_train,X_test,Num,max_mat_elements )
%KNN_distance_matrix obtains the KNN distance matrix which is similar (but not identical) to Matlab built-in function knnsearch
%
%	Syntax
%
%       [ dist_val, dist_idx ] = KNN_distance_matrix( X_train,X_test,Num,max_mat_elements )
%
%	Description
%
%   KNN_distance_matrix takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       Num         - Number of nearest neighbors considered (default 10)
%   and returns,
%       dist_val	- An pxNum array, dist_val(i,:) contains the index of K nearest neighbor in X_train for X_test(i,:) in ascending order
%       dist_idx	- An pxNum array, dist_idx(i,:) contains the distance of K nearest neighbor in X_train for X_test(i,:) corresponding to dist_val
%	NOTE: If X_test is X_train, then the nearest neighbor in X_train for X_test(i,:) (i.e., X_test(i,:) itself) is not included in the outputs
%see also Matlab built-in function knnsearch

    % default parameters setting
    if nargin < 4
        max_mat_elements=1000*1000;%maximum matrix elements
    end
    if nargin < 3
        Num = 10;
    end
    if nargin < 2
        error('Not enough input parameters!');
    end
    num_training = size(X_train,1);%number of training set inst.
    num_testing = size(X_test,1);%number of testing set inst.
    %judge that whether the testing set equals training set (used for training set ifself)
    if num_training==num_testing
        if sum(sum(abs(X_train-X_test)))<1e-3
            the_same_flag = 1;
        else
            the_same_flag = 0;
        end    
    else
        the_same_flag = 0;
    end
    %block_size*num_training <=max_mat_elements
    block_size=floor(max_mat_elements/num_training);
    num_blocks=ceil(num_testing/block_size);
    %initialize outputs
    dist_val = zeros(num_testing,Num);
    dist_idx = zeros(num_testing,Num);
    %main loop
    for iter=1:num_blocks
        %determine starting index low & ending index high of this loop
        low=block_size*(iter-1)+1;
        if(iter==num_blocks)
            high=num_testing;
        else
            high=block_size*iter;
        end
        %determine sub-distance matrix
        tmp_data=X_test(low:high,:);
        tmp_size=size(tmp_data,1);
        mat1=repmat(sum(X_train.^2,2),1,tmp_size);
        mat2=repmat(sum(tmp_data.^2,2),1,num_training)';
        tmp_dist_matrix=mat1+mat2-2*X_train*tmp_data';
        tmp_dist_matrix=sqrt(tmp_dist_matrix);
        tmp_dist_matrix=tmp_dist_matrix';
        %distance between instance and itself should be set as positive infinity 
        if the_same_flag
            for i=low:high
                tmp_dist_matrix(i-low+1,i)=realmax;
            end
        end
        for i=low:high
            %sort the distances between instane #i and intances in
            %training set in ascending order
            [temp,index]=sort(tmp_dist_matrix(i-low+1,:));
            dist_val(i,:) = temp(1:Num);%output
            dist_idx(i,:) = index(1:Num);%output
        end
    end
end

