function [ cramer_V ] = CramersV( x1,x2 )
%Author: Jia Bin-Bin
%Version: 1.0@2019-05-27
%Description: compute variable Cramer's V between x1&x2
%Reference: Cram��r H. Mathematical Methods of Statistics. Princeton University Press, page 282 (Chapter 21. The two-dimensional case)
% or an intuitive introduction in Chinese: ���� ��/��, �¸�/��. ����ͳ��ѧ. ��ѧ������, 2009: 127-142.

    %Step 1: Observed frequency(contigency table )
    sym_x1 = unique(x1);
    sym_x2 = unique(x2);
    contigency_tab = zeros(length(sym_x1),length(sym_x2));
    for i=1:length(sym_x1)
        for j=1:length(sym_x2)
            ind_x1 = (x1==sym_x1(i));
            ind_x2 = (x2==sym_x2(j));
            contigency_tab(i,j) = sum(ind_x1&ind_x2);
        end
    end

    %Step 2: Expected frequency
    contigency_mean = zeros(length(sym_x1),length(sym_x2));
    for i=1:length(sym_x1)
        for j=1:length(sym_x2)
            contigency_mean(i,j) = sum(contigency_tab(i,:))*sum(contigency_tab(:,j))/sum(contigency_tab(:));
        end
    end

    %Step 3&4: Pearson chi-square statistic
    chi_square = sum(sum(((contigency_tab - contigency_mean).^2)./contigency_mean));

    %Step 5: Cramer's V
    cramer_V = sqrt(chi_square/sum(contigency_tab(:))/(min(length(sym_x1),length(sym_x2))-1));
end

