function [ Eval,y_predict ] = PAIR( X_train, y_train, X_test, y_test )
%PAIR implements the first simplified version of SEEM approach (i.e. PAIR) as described in [1]
%Type 'help PAIR' under Matlab prompt for more detailed information about PAIR
%
%	Syntax
%
%       [ Eval,y_predict ] = PAIR( X_train, y_train, X_test, y_test )
%
%	Description
%
%   PAIR takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       y_test      - An pxq array, the ith class vector of testing instance is stored in y_test(i,:)
%   and returns,
%       Eval	    - A struct where 
%						Eval.HS correpsonds to the hamming score on testing data as described in [1]
%						Eval.EM correpsonds to the exact match on testing data as described in [1]
%						Eval.SEM correpsonds to the sub-exact match on testing data as described in [1]
%       y_predict	- An pxq array, the predicted class matrix for test instance matrix X_test
%
%  [1] B.-B. Jia, M.-L. Zhang. Multi-Dimensional Classification via Stacked Dependency Exploitation, In: Sci. China Inf. Sci. (2020) in press.
%
%See also CramersV.

    %obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end
    %compute cramersV for all dim pairs
    d1_set = zeros(1,num_dim*(num_dim-1)/2);
    d2_set = zeros(1,num_dim*(num_dim-1)/2);
    cramersV_set = zeros(1,num_dim*(num_dim-1)/2);
    idx_cnt = 1;
    for d1=1:num_dim-1
        for d2=d1+1:num_dim
            d1_set(idx_cnt) = d1;
            d2_set(idx_cnt) = d2;
            cramersV_set(idx_cnt) = CramersV(y_train(:,d1),y_train(:,d2));
            idx_cnt = idx_cnt + 1;
        end
    end
    %seek maximum cramersV from candidate pairs
    theta = zeros(ceil(num_dim/2),2);
    cramersV_pair = zeros(ceil(num_dim/2),1);
    for ii=1:floor(num_dim/2)
        [cramersV_pair(ii), max_idx] = max(cramersV_set);
        theta(ii,1) = d1_set(max_idx);
        theta(ii,2) = d2_set(max_idx);
        idx_del = (d1_set==theta(ii,1))|(d2_set==theta(ii,1))|(d1_set==theta(ii,2))|(d2_set==theta(ii,2));
        cramersV_set(idx_del) = -1;
    end
    if mod(num_dim,2)==1%when num_dim is odd
        theta(end,1) = setdiff(1:num_dim,theta(:));
    end
    %learning process
    y_predict = zeros(size(y_test));
    for ii=1:floor(num_dim/2)
        [C_y_mdc,~,ic_y_mdc] = unique(y_train(:,theta(ii,:)),'rows');
        %training&testing by LIBSVM with linear kernel
        model_train = svmtrain(ic_y_mdc,X_train,'-t 0 -q');
        [predicted_label_LP,~,~] = svmpredict(ones(num_testing,1),X_test, model_train, '-q');
%         %training&testing by logistic regression via LIBLINEAR
%         model_train = train(ic_y_mdc,sparse(X_train),'-s 0 -B 1 -q');
%         [predicted_label_LP,~,~] = predict(ones(num_testing,1),sparse(X_test), model_train, '-q');
%         %training&testing by CART via Matlab built-in function fitctree
%         ctree = fitctree(X_train, ic_y_mdc, 'CategoricalPredictors',cat_attr);
%         predicted_label_LP = predict(ctree, X_test);
        y_predict(:,theta(ii,:)) = C_y_mdc(predicted_label_LP,:);
    end
    if mod(num_dim,2)==1%when num_dim is odd
        %training&testing by LIBSVM with linear kernel
        model_train = svmtrain(y_train(:,theta(end,1)),X_train,'-t 0 -q');
        [y_predict(:,theta(end,1)),~,~] = svmpredict(ones(num_testing,1),X_test, model_train, '-q');
%         %training&testing by logistic regression via LIBLINEAR
%         model_train = train(y_train(:,theta(end,1)),sparse(X_train),'-s 0 -B 1 -q');
%         [y_predict(:,theta(end,1)),~,~] = predict(ones(num_testing,1),sparse(X_test), model_train, '-q');
%         %training&testing by CART via Matlab built-in function fitctree
%         ctree = fitctree(X_train, y_train(:,theta(end,1)), 'CategoricalPredictors',cat_attr);
%         y_predict(:,theta(end,1)) = predict(ctree,X_test);
    end
    Eval.HS = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    Eval.EM = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    Eval.SEM = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);
end