%This is an examplar file on how the SEEM program could be used (The main function is "SEEM.m")
%
%Type 'help SEEM' under Matlab prompt for more detailed information
%
%N.B.: Please ensure that libsvm package [1] (as attached) is put under the matlab path before envoking the SEEM function.
%
%[1] Chang, C.-C., and Lin, C.-J. 2011. LIBSVM: A library for support vector machines. ACM Transactions on Intelligent Systems and Technology 2: Article 27. Software available at https://www.csie.ntu.edu.tw/~cjlin/libsvm/index.html

clc;clear;close;
% Load the file containing the necessary inputs for calling the SEEM function
load('sample data.mat'); 

% The number of nearest neighbors considered for SEEM
NumK=10;

% Calling the main function SEEM
[ Eval,y_predict ] = SEEM( X_train, y_train, X_test, y_test, NumK );
disp(['HammingScore=',num2str(Eval.HS,'%4.3f'),', ExactMatch=',num2str(Eval.EM,'%4.3f'),', SubExactMatch=',num2str(Eval.SEM,'%4.3f')]);