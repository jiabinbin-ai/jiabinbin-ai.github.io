function [ Eval,y_predict ] = STACK( X_train, y_train, X_test, y_test )
%STACK implements the third simplified version of SEEM approach (i.e. STACK) as described in [1]
%Type 'help STACK' under Matlab prompt for more detailed information about STACK
%
%	Syntax
%
%       [ Eval,y_predict ] = STACK( X_train, y_train, X_test, y_test )
%
%	Description
%
%   STACK takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       y_test      - An pxq array, the ith class vector of testing instance is stored in y_test(i,:)
%   and returns,
%       Eval	    - A struct where 
%						Eval.HS correpsonds to the hamming score on testing data as described in [1]
%						Eval.EM correpsonds to the exact match on testing data as described in [1]
%						Eval.SEM correpsonds to the sub-exact match on testing data as described in [1]
%       y_predict	- An pxq array, the predicted class matrix for test instance matrix X_test
%
%  [1] B.-B. Jia, M.-L. Zhang. Multi-Dimensional Classification via Stacked Dependency Exploitation, In: Sci. China Inf. Sci. (2020) in press.
%
%See also LabelTrans_md2ml.

    %obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end
    %Step 1: train&test
    y_pre_train_cell = cell(num_dim,1);
    y_pre_test_cell = cell(num_dim,1);
    for d1 = 1:num_dim-1
        for d2 = d1+1:num_dim
            [C_y_pair,~,y_pair_cp] = unique(y_train(:,[d1,d2]),'rows');
            %training&testing by LIBSVM with linear kernel
            model_pair = svmtrain(y_pair_cp,X_train,'-t 0 -q');
            y_pair_cp_train_pre = svmpredict(ones(num_training,1),X_train, model_pair,'-q');
            y_pair_cp_test_pre = svmpredict(ones(num_testing,1),X_test, model_pair,'-q');
%             %%you can also use other multi-class algorithm to accomplish above training&testing steps
%             %such as logistic regression via LIBLINEAR
%             model_pair = train(y_pair_cp,sparse(X_train),'-s 0 -B 1 -q');
%             y_pair_cp_train_pre = predict(ones(num_training,1),sparse(X_train), model_pair, '-q');
%             y_pair_cp_test_pre = predict(ones(num_testing,1),sparse(X_test), model_pair, '-q');
%             %or CART via Matlab built-in function fitctree, where 'cat_attr' represents the index of categorical features 
%             ctree_pair = fitctree(X_train, y_pair_cp, 'CategoricalPredictors',cat_attr);
%             y_pair_cp_train_pre = predict(ctree_pair, X_train);
%             y_pair_cp_test_pre = predict(ctree_pair, X_test);
            
            %transform pairwise-powerset predictions to original ones
            y_pair_train_pre = C_y_pair(y_pair_cp_train_pre,:);
            y_pair_test_pre = C_y_pair(y_pair_cp_test_pre,:);
            
            %save predictions
            y_pre_train_cell{d1} = [y_pre_train_cell{d1},y_pair_train_pre(:,1)];
            y_pre_train_cell{d2} = [y_pre_train_cell{d2},y_pair_train_pre(:,2)];
            y_pre_test_cell{d1} = [y_pre_test_cell{d1},y_pair_test_pre(:,1)];
            y_pre_test_cell{d2} = [y_pre_test_cell{d2},y_pair_test_pre(:,2)];
        end
    end
    %Step 2: transformation
    y_train_pre_label_pure_cell = cell(num_dim,1);
    y_test_pre_label_pure_cell = cell(num_dim,1);
    for dd = 1:num_dim
        for inter_dd = 1:num_dim-1
            %train
            this_dim_y_i = y_pre_train_cell{dd}(:,inter_dd);
            y_pre_label_pure = LabelTrans_md2ml(this_dim_y_i,C_per_dim(dd),[1;-1]);
            y_train_pre_label_pure_cell{dd} = [y_train_pre_label_pure_cell{dd},y_pre_label_pure];
            
            %test
            this_dim_y_i = y_pre_test_cell{dd}(:,inter_dd);
            y_pre_label_pure = LabelTrans_md2ml(this_dim_y_i,C_per_dim(dd),[1;-1]);
            y_test_pre_label_pure_cell{dd} = [y_test_pre_label_pure_cell{dd},y_pre_label_pure];          
        end            
    end
    %Step 3: pure stacking 
    y_predict = zeros(size(y_test));    
    for dd=1:num_dim
        %training&testing by LIBSVM with linear kernel
        model_knn = svmtrain(y_train(:,dd),y_train_pre_label_pure_cell{dd},'-t 0 -q'); 
        [y_predict(:,dd), ~, ~] = svmpredict(ones(num_testing,1),y_test_pre_label_pure_cell{dd}, model_knn,'-q');
%         %training&testing by logistic regression via LIBLINEAR
%         model_knn = train(y_train(:,dd),sparse(y_train_pre_label_pure_cell{dd}),'-s 0 -B 1 -q'); 
%         [y_predict(:,dd), ~, ~] = predict(ones(num_testing,1),sparse(y_test_pre_label_pure_cell{dd}), model_knn,'-q');
%         %training&testing by CART via Matlab built-in function fitctree
%         ctree_pure = fitctree(y_train_pre_label_pure_cell{dd}, y_train(:,dd));
%         y_predict(:,dd) = predict(ctree_pure, y_test_pre_label_pure_cell{dd});
    end
    Eval.HS = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    Eval.EM = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    Eval.SEM = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);
end