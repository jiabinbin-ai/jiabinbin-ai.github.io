function [ y_predict ] = BClassifier_test( model, X_test )
%BClassifier_test implements the prediction phase of binary classifier
%Type 'help BClassifier_test' under Matlab prompt for more detailed information about BClassifier_test
%
%	Syntax
%
%       [ y_predict ] = BClassifier_test( model, X_test )
%
%	Description
%
%   BClassifier_test takes,
%       model       - The learned model
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%
%   and returns,
%       y_predict	- An px1 array, the predicted class vector for test instance matrix X_test
%
% see also BClassifier_train

    %Here, we use liblinear with parameter setting "L2-regularized logistic
    %regression (primal)" to serve as the base binary classifier to implement EDCC. 
    %Other kinds of binary classifers also can be used according to your own needs.
    y_predict = predict(ones(size(X_test,1),1),sparse(X_test), model, '-q');

end