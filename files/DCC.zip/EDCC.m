function [ Eval,y_predict ] = EDCC( X_train, y_train, X_test, y_test, EnSize, write_file )
%EDCC implements the Ensemble of Decomposed-based Classifier Chains approach as described in [1]
%Type 'help EDCC' under Matlab prompt for more detailed information about EDCC
%
%	Syntax
%
%       [ Eval,y_predict ] = EDCC( X_train, y_train, X_test, y_test, EnSize, write_file )
%
%	Description
%
%   EDCC takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       y_test      - An pxq array, the ith class vector of testing instance is stored in y_test(i,:)
%       EnSize      - Ensemble size of DCC (default 10)
%       write_file  - A struct where 
%                       write_file.file_id corresponds to the file identifier (default 1, i.e., output to screen)
%                       write_file.head_str corresponds to the head string (default '   ');
%                       write_file.verbose: 1-outputs, 0-no ouputs  (default 1)
%   and returns,
%       Eval	    - A struct where 
%						Eval.HS correpsonds to the hamming score on testing data as described in [1]
%						Eval.EM correpsonds to the exact match on testing data as described in [1]
%						Eval.SEM correpsonds to the sub-exact match on testing data as described in [1]
%       y_predict	- An pxq array, the predicted class matrix for test instance matrix X_test
%
%  [1] Bin-Bin Jia, Min-Ling Zhang. Decomposition-based Classifier Chains for Multi-Dimensional Classification, In: IEEE Transactions on Artificial Intelligence, 2021, in press.
%
    if nargin<5
        EnSize = 10;
    end
    if nargin<6
        write_file.file_id = 1;
        write_file.head_str = '   ';
        write_file.verbose = 1;
    end
    file_id = write_file.file_id;
    head_str = write_file.head_str;
    verbose = write_file.verbose;

    % Obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end

    %One-vs-One decomposition
    if verbose
        temp_str = [head_str,'One versus one decomposition(',disp_time(clock,0),')...\n'];
        fprintf(file_id,temp_str);
    end
    num_ovo_dim = num_per_dim.*(num_per_dim-1)/2;
    num_ovo = sum(num_ovo_dim);
    y_train_ovo = zeros(num_training,num_ovo);
    y_code_ovo = zeros(2,num_ovo);
    y_code_dim_idx = zeros(1,num_ovo);
    cnt_ovo = 1;
    for dd=1:num_dim
        for a1=1:num_per_dim(dd)-1
            label_p = C_per_dim{dd}(a1);
            for a2=a1+1:num_per_dim(dd)
                label_n = C_per_dim{dd}(a2);
                tmp_y = zeros(num_training,1);
                tmp_y(y_train(:,dd)==label_p) = +1;
                tmp_y(y_train(:,dd)==label_n) = -1;
                y_train_ovo(:,cnt_ovo) = tmp_y;
                %save OvO code table
                y_code_ovo(1,cnt_ovo) = label_p;
                y_code_ovo(2,cnt_ovo) = label_n;
                y_code_dim_idx(cnt_ovo) = dd;
                cnt_ovo = cnt_ovo + 1;
            end
        end
    end

    %make ensembles of base CC's results
    Ensemble_size = EnSize;
    y_predict_s = cell(Ensemble_size,1);
    num_b_label = num_ovo;
    for jj=1:Ensemble_size
        if verbose
            temp_str = [head_str,'The (',num2str(jj),'/',num2str(Ensemble_size),')th DCC base classifier start(',disp_time(clock,0),')...\n'];
            fprintf(file_id,temp_str);
        end
        if Ensemble_size>1
            rand('state', jj);
            bag_flag = true;
            while bag_flag%ensure all class labels are included in the randomly sampled data set
                idx_bag = randsample(1:num_training,num_training,'true',ones(1,num_training));
                tmp_train = y_train(idx_bag,:);
                empty_flag = zeros(num_dim,1);
                for dd=1:num_dim
                    temp_C = unique(tmp_train(:,dd));
                    dif_class = setdiff(C_per_dim{dd},temp_C);
                    empty_flag(dd) = isempty(dif_class);                        
                end
                if sum(empty_flag)==num_dim
                    bag_flag = false;
                end
            end
            X_train_bag = X_train(idx_bag,:);
            y_train_ovo_bag = y_train_ovo(idx_bag,:);
        else%single DCC classifier
            X_train_bag = X_train;
            y_train_ovo_bag = y_train_ovo;            
        end
        %assign an order for each CC randomly
        if Ensemble_size>1
            rand('state', jj+1);
        end
        CC_order = randperm(num_b_label);
        % training phase
        model_train = cell(num_b_label,1);
        y_train_b_pre = zeros(size(y_train_ovo_bag));
        for idx_cc = 1:num_b_label
            idx_the_ovo = (y_train_ovo_bag(:,CC_order(idx_cc))~=0);
            X_train_cc = [X_train_bag,y_train_b_pre(:,CC_order(1:idx_cc-1))];
            model_train{idx_cc} = BClassifier_train( X_train_cc(idx_the_ovo,:), y_train_ovo_bag(idx_the_ovo,CC_order(idx_cc)) );
            tmp_y = BClassifier_test( model_train{idx_cc}, X_train_cc );
            tmp_y(tmp_y==-1) = 0;%use 0 to denote negative class as input attributes are normalized into [0,1]
            y_train_b_pre(:,CC_order(idx_cc)) = tmp_y;
        end
        % testing phase
        predicted_label_cc = zeros(num_testing,num_b_label);
        for idx_cc = 1:num_b_label
            X_test_cc = [X_test,predicted_label_cc(:,CC_order(1:idx_cc-1))];
            tmp_y = BClassifier_test( model_train{idx_cc}, X_test_cc );
            tmp_y(tmp_y==-1) = 0;%use 0 to denote negative class as input attributes are normalized into [0,1]
            predicted_label_cc(:,CC_order(idx_cc)) = tmp_y;
        end
        y_predict_test_b = predicted_label_cc;
        %One-vs-One decoding for test set
        y_test_code_pre = zeros(size(y_predict_test_b));
        y_predict_test_s = zeros(size(y_test));
        for iiovo=1:num_testing
            for jjovo=1:num_ovo
                if y_predict_test_b(iiovo,jjovo)==1
                    y_test_code_pre(iiovo,jjovo) = y_code_ovo(1,jjovo);
                else
                    y_test_code_pre(iiovo,jjovo) = y_code_ovo(2,jjovo);
                end
            end
            for dd=1:num_dim
                tmp_idx = sum(num_ovo_dim(1:dd-1))+1:sum(num_ovo_dim(1:dd));
                tmp_y_code = y_test_code_pre(iiovo,tmp_idx);
                tmp_cnt = zeros(num_per_dim(dd),1);
                for jjovo=1:num_per_dim(dd)
                    tmp_cnt(jjovo) = sum(tmp_y_code == C_per_dim{dd}(jjovo));
                end
                [p_val,p_pos] = max(tmp_cnt);
                y_predict_test_s(iiovo,dd) = C_per_dim{dd}(p_pos);
            end
        end
        y_predict_s{jj} = y_predict_test_s;
    end

    %majority voting
    if Ensemble_size>1
        y_predict = zeros(size(y_test));
        for ii=1:size(y_test,1)
            for jj=1:size(y_test,2)
                temp_label = zeros(Ensemble_size,1);
                for kk=1:Ensemble_size
                   temp_label(kk) =  y_predict_s{kk}(ii,jj);
                end
                [C,ia,ic] = unique(temp_label);
                temp_cnt = zeros(length(ia),1);
                for kk=1:length(ia)
                    temp_cnt(kk) = sum(ic==kk);
                end
                if sum(temp_cnt)~=Ensemble_size
                    error('There is sth. wrong with temp_cnt');
                end
                [tempmax,index]=max(temp_cnt);
                if index==length(temp_cnt)
                    y_predict(ii,jj)=C(index);  
                else
                    indexmax = index;
                    for kk=index+1:length(temp_cnt)
                        if temp_cnt(kk)==tempmax
                            indexmax = kk;
                        end
                    end
                    y_predict(ii,jj)=C(indexmax);  
                end
            end
        end
	else%single DCC classifier
        y_predict = y_predict_s{jj};
    end
    %Performance evaluation
    Eval.HS = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    Eval.EM = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    Eval.SEM = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);
end