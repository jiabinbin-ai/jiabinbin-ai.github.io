function [ model ] = BClassifier_train( X_train, y_train )
%BClassifier_test implements the training phase of binary classifier
%Type 'help BClassifier_train' under Matlab prompt for more detailed information about BClassifier_train
%
%	Syntax
%
%       [ model ] = BClassifier_train( X_train, y_train )
%
%	Description
%
%   BClassifier_test takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mx1 array, the class vector for training instance matrix X_train
%
%   and returns,
%       model       - The learned model
%
% see also BClassifier_test

    %Here, we use liblinear with parameter setting "L2-regularized logistic
    %regression (primal)" to serve as the base binary classifier to implement EDCC. 
    %Other kinds of binary classifers also can be used according to your own needs.
    model = train(y_train,sparse(X_train),'-s 0 -B 1 -q');

end