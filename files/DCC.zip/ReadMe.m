%This is an examplar file on how the EDCC program could be used (The main function is "EDCC.m")
%
%Type 'help EDCC' under Matlab prompt for more detailed information
%
%N.B.: It necessiates a base binary classifier to implement EDCC, where we
%use liblinear [1] (as attached) with the setting "L2-regularized logistic
%regression (primal)" to serve as this purpose here. Other kinds of binary
%classifers also can be used according to your own needs, you just need to
%update the two functions BClassifier_train&BClassifier_test accordingly.
%
%[1] R.-E. Fan, K.-W. Chang, C.-J. Hsieh, X.-R. Wang, and C.-J. Lin. LIBLINEAR: A library for large linear classification, Journal of Machine Learning Research 9(2008), 1871-1874. Software available at https://www.csie.ntu.edu.tw/~cjlin/liblinear/

clc;clear;close;
% Load the file containing the necessary inputs for calling the EDCC function
load('sample data.mat'); 

% ensemble size
EnSize = 10;

% Calling the main function EDCC
[ Eval,y_predict ] = EDCC( X_train,y_train,X_test,y_test,EnSize);
disp(['HammingScore=',num2str(Eval.HS,'%4.3f'),', ExactMatch=',num2str(Eval.EM,'%4.3f'),', SubExactMatch=',num2str(Eval.SEM,'%4.3f')]);