%This is an examplar file on how the DLEM program could be used (The main function is "DLEM.m")
%
%Type 'help DLEM' under Matlab prompt for more detailed information
%

% Loading the file containing the necessary inputs for calling the DLEM function
load('sample data.mat'); 

%parameters
para.lambda = 1;
para.gamma = 10;
para.mu = 1;
para.numK = 6;

% Calling the main function DLEM
[ Eval,y_predict ] = DLEM(X_train,y_train,X_test,y_test,para);
disp(['HammingScore=',num2str(Eval.HS,'%4.3f'),', ExactMatch=',num2str(Eval.EM,'%4.3f'),', SubExactMatch=',num2str(Eval.SEM,'%4.3f')]);