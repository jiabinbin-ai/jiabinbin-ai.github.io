function [ Eval,y_predict ] = DLEM( X_train,y_train,X_test,y_test,para,write_file )
%DLEM implements the DLEM approach as described in [1]
%Type 'help DLEM' under Matlab prompt for more detailed information about DLEM
%
%	Syntax
%
%       [ Eval,y_predict ] = DLEM( X_train,y_train,X_test,y_test,para,write_file )
%
%	Description
%
%	DLEM takes
%       X_train	- An mxd array, the ith training instance is stored in X_train(i,:)
%       y_train	- An mxq array, the class vector of ith training instance is stored in y_train(i,:)
%       X_test	- An pxd array, the ith testing instance is stored in X_test(i,:)
%       y_test	- An pxq array, the class vector of ith testing instance is stored in y_test(i,:)
%       para	- A struct variable that stores hyperparameters, where
%               para.lambda: trade-off parameter in Eq.(6) (default 1)
%               para.gamma: trade-off parameter in Eq.(9) (default 10)
%               para.mu: trade-off parameter in Eq.(10) (default 1)
%               para.numK: number of nearest neighbors considered in Eq.(3) and Eq.(10) (default 6)
%       write_file  - A struct where 
%               write_file.file_id corresponds to the file identifier (default 1, i.e., output to screen)
%               write_file.head_str corresponds to the head string (default '   ');
%               write_file.verbose: 1-outputs, 0-no ouputs  (default 1)
%
%   and returns,
%       Eval	    - A struct where 
%						Eval.HS correpsonds to the hamming score on testing data as described in [1]
%						Eval.EM correpsonds to the exact match on testing data as described in [1]
%						Eval.SEM correpsonds to the sub-exact match on testing data as described in [1]
%       y_predict	- An pxq array, the predicted class matrix for test instance matrix X_test
%
%  [1] B.-B. Jia, M.-L. Zhang. Multi-Dimensional Classification via Decomposed Label Encoding, In: IEEE Transactions on Knowledge and Data Engineering, 2021, in press.

    if nargin<5
        para.lambda = 1;
        para.gamma = 10;
        para.mu = 1;
        para.numK = 6;
    end
    if nargin<6
        write_file.file_id = 1;
        write_file.head_str = '   ';
        write_file.verbose = 1;
    end
    file_id = write_file.file_id;
    head_str = write_file.head_str;
    verbose = write_file.verbose;
    
    % Obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end
        
    % (S1) Decomposed Label Encoding
    temp_str = [head_str,'Step 1: Decomposed Label Encoding (',disp_time(clock,0),')...\n'];
    fprintf(file_id,temp_str);
    num_ovo_dim = num_per_dim.*(num_per_dim-1)/2;
    num_ovo = sum(num_ovo_dim);%i.e., $\ell$ in our paper
    y_train_ovo = zeros(num_training,num_ovo);%i.e., the matrix $\bf L$ in our paper
    y_code_ovo = zeros(2,num_ovo);
    y_code_dim_idx = zeros(1,num_ovo);
    cnt_ovo = 1;
    for dd=1:num_dim
        for a1=1:num_per_dim(dd)-1
            label_p = C_per_dim{dd}(a1);
            for a2=a1+1:num_per_dim(dd)
                label_n = C_per_dim{dd}(a2);
                tmp_y = zeros(num_training,1);
                tmp_y(y_train(:,dd)==label_p) = +1;
                tmp_y(y_train(:,dd)==label_n) = -1;
                y_train_ovo(:,cnt_ovo) = tmp_y;
                %save OvO code table
                y_code_ovo(1,cnt_ovo) = label_p;
                y_code_ovo(2,cnt_ovo) = label_n;
                y_code_dim_idx(cnt_ovo) = dd;
                cnt_ovo = cnt_ovo + 1;
            end
        end
    end
     
    temp_str = [head_str,'Step 2: Labeling Information Enrichment (',disp_time(clock,0),')...\n'];
    fprintf(file_id,temp_str);
    numK = para.numK;
    %(2.1) Obtain the linear combination coefficients matrix S via solving Eq.(4)
    [idx_train, dist_train] = knnsearch(X_train,X_train,'K',numK+1);
    S = zeros(num_training);
    for itrain=1:num_training
        dist0_idx = (dist_train(itrain,2:end)==0);%excluding the instance itself
        if sum(dist0_idx)>0%if there are other instances who are exactly identical with the current one
            si = zeros(numK,1);
            si(dist0_idx) = 1/sum(dist0_idx);
        else
            XK = transpose(X_train(idx_train(itrain,2:end),:));
            Xi = repmat(transpose(X_train(itrain,:)),1,numK);
            Ci = (Xi-XK)'*(Xi-XK);
            si = pinv(Ci)*ones(numK,1)/(ones(1,numK)*pinv(Ci)*ones(numK,1));
        end
        S(idx_train(itrain,2:end),itrain) = si;%si/sum(si);
    end
    %(2.2) Obtain the enriched label matrix F via solving Eq.(7)
    St = (eye(num_training)-S)*(eye(num_training)-S)'+para.lambda*eye(num_training);
    F_train = para.lambda*pinv(St)*y_train_ovo;%i.e., the matrix $\bf F$ in our paper
    
    temp_str = [head_str,'Step 3: Predictive Model Induction (',disp_time(clock,0),')...\n'];
    fprintf(file_id,temp_str);
    Kpara.type = 'RBF';%RBF kernel
    if num_training<2000
        Kpara.gamma  = 1/2/std(pdist(X_train))^2; %parameter of kernel function
    else
        Kpara.gamma  = 1/2/std(pdist(X_train(1:2000,:)))^2; %parameter of kernel function
    end
    Rpara.gamma = para.gamma/num_training;
    Rpara.mu = para.mu*num_training;
    Rpara.numK = para.numK;
    Rpara.file_id = file_id;
    Rpara.head_str = [head_str,'   '];
    Rpara.verbose = verbose;
    Theta = Multioutput_regression(F_train,X_train,Kpara,Rpara);%induce multi-output regression model
    
    %Testing phase
    F_test = Kernel(X_test,X_train,Kpara)*Theta;
    y_test_code_pre = zeros(size(F_test));
    y_predict = zeros(size(y_test));
    for ii=1:num_testing
        for jj=1:num_ovo
            if F_test(ii,jj)>=0
                y_test_code_pre(ii,jj) = y_code_ovo(1,jj);
            else
                y_test_code_pre(ii,jj) = y_code_ovo(2,jj);
            end
        end
        for dd=1:num_dim
            tmp_idx = sum(num_ovo_dim(1:dd-1))+1:sum(num_ovo_dim(1:dd));
            tmp_y_code = y_test_code_pre(ii,tmp_idx);
            tmp_cnt = zeros(num_per_dim(dd),1);
            for jj=1:num_per_dim(dd)
                tmp_cnt(jj) = sum(tmp_y_code == C_per_dim{dd}(jj));
            end
            [p_val,p_pos] = max(tmp_cnt);
            y_predict(ii,dd) = C_per_dim{dd}(p_pos);
        end
    end
    
    %Hamming Score(or Class Accuracy)
    Eval.HS = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    %Exact Match(or Example Accuracy or Subset Accuracy)
    Eval.EM = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    %Sub-ExactMatch
    Eval.SEM = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);
end 
