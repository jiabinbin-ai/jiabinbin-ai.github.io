function [ y_test_pre,w_multi,y_train_pre ] = MCClassifier(X_test,y_train,X_train,num_f_L2,para_setting)
%MCClassifier implements the multi-class classifier used by SFAM [1] via one-vs-rest decomposition strategy
%Type 'help MCClassifier' under Matlab prompt for more detailed information about MCClassifier
%
%	Syntax
%
%       [ y_test_pre,w_multi,y_train_pre ] = MCClassifier(X_test,y_train,X_train,num_f_L2,para_setting)
%
%	Description
%
%   MCClassifier takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mx1 array, the ith class of training instance is stored in y_train(i)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       num_f_L2    - The first num_f_L2 features correspond to L2 regularization
%       para_setting- A struct where 
%                       para_setting.lambda1 corresponds to the trade-off parameter for the L2 regularization (default 1)
%                       para_setting.lambda2 corresponds to the trade-off parameter for the L1 regularization (default 1)
%                       para_setting.file_id corresponds to the file identifier (default 1, i.e., output to screen)
%                       para_setting.head_str corresponds to the head string (default '   ');
%                       para_setting.verbose: 1-outputs, 0-no ouputs  (default 1)
%   and returns,
%       y_test_pre  - An pxq array, the predicted class matrix for test instance matrix X_test
%       w_multi     - An (d+1)xC array, the weight matrix, where C is the number of classes (NB: for binary classification, C=1)
%       y_train_pre - An mxq array, the predicted class matrix for train instance matrix X_train
%
%  [1] Bin-Bin Jia, Min-Ling Zhang. Multi-Dimensional Classification via Selective Feature Augmentation, In: International Journal of Automation and Computing, in press.
%
%See also BClassifier.

    if nargin<5
        para_setting.lambda1 = 1;%trade-off parameter for the L2 regularization
        para_setting.lambda2 = 1;%trade-off parameter for the L1 regularization
        para_setting.file_id = 1;
        para_setting.head_str = '   ';
        para_setting.verbose = 1;        
    end
    all_fid = para_setting.file_id;
    head_str = para_setting.head_str;
    verbose = para_setting.verbose;
    para_setting.head_str = [head_str,'   '];
    symb = unique(y_train);
    num_symb = length(symb);%number of classes
    [num_testing,num_features] = size(X_test);
    if num_symb == 1
        if verbose
            fprintf(all_fid,[head_str,'[WARNING]There is only one unique label in training set!\n']); 
        end
        y_test_pre = symb*ones(num_testing,1);
        y_train_pre = symb*ones(size(y_train));
        w_multi = zeros(num_features+1,1);
    elseif num_symb == 2%binary classification
        if verbose
            fprintf(all_fid,[head_str,'There are two unique labels in training set!\n']);
        end
        y = zeros(size(y_train));
        y(y_train==symb(1)) = 1;%symb(1)-->1, symb(2)-->0
        %training phase
        w_multi = BClassifier(y,X_train,num_f_L2,para_setting);
        %testing phase
        %(1)testing set
        X = [ones(num_testing,1),X_test];
        f_val = X*w_multi;
        y_test_pre = zeros(num_testing,1);
        y_test_pre(f_val>0) = symb(1);
        y_test_pre(f_val<=0) = symb(2);
        %(2)training set
        X = [ones(size(y_train)),X_train];
        f_val = X*w_multi;
        y_train_pre = zeros(size(y_train));
        y_train_pre(f_val>0) = symb(1);
        y_train_pre(f_val<=0) = symb(2);
    else%multi-class classification
        if verbose
            fprintf(all_fid,[head_str,'There are ',num2str(num_symb),' unique labels in training set, one-vs-rest strategy will be used!\n']); 
        end
        %training phase (one-vs-rest)
        w_multi = zeros(num_features+1,num_symb);
        for ii=1:num_symb
            if verbose
                fprintf(all_fid,[head_str,'   The (',num2str(ii),'/',num2str(num_symb),') one-vs-rest begin...\n']);
            end
            y = zeros(size(y_train));
            y(y_train==symb(ii)) = 1;%%symb(ii)-->1, others-->0
            w_multi(:,ii) = BClassifier(y,X_train,num_f_L2,para_setting);
        end
        %testing phase
        %(1)testing set
        X = [ones(num_testing,1),X_test];
        f_val = X*w_multi;
        [~,max_p] = max(f_val,[],2);
        y_test_pre = symb(max_p);
        %(2)training set
        X = [ones(size(y_train)),X_train];
        f_val = X*w_multi;
        [~,max_p] = max(f_val,[],2);
        y_train_pre = symb(max_p);
    end
end