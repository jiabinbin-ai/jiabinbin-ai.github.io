function [ w ] = BClassifier(y_train,X_train,num_f_L2,para_setting)
%BClassifier implements the binary classifier where the loss function is cross-entropy loss and the regularization includes both L1 and L2 terms.
%Type 'help BClassifier' under Matlab prompt for more detailed information about BClassifier
%
%	Syntax
%
%       [ w ] = BClassifier(y_train,X_train,num_f_L2,para_setting)
%
%	Description
%
%   MCClassifier takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mx1 array, the ith class of training instance is stored in y_train(i)
%       num_f_L2    - The first num_f_L2 features correspond to L2 regularization
%       para_setting- A struct where 
%                       para_setting.lambda1 corresponds to the trade-off parameter for the L2 regularization (default 1)
%                       para_setting.lambda2 corresponds to the trade-off parameter for the L1 regularization (default 1)
%                       para_setting.file_id corresponds to the file identifier (default 1, i.e., output to screen)
%                       para_setting.head_str corresponds to the head string (default '   ');
%                       para_setting.verbose: 1-outputs, 0-no ouputs  (default 1)
%   and returns,
%       w           - An (d+1)x1 array, the weight vector, where the first element corresponds to the bias term.
%
%  [1] Bin-Bin Jia, Min-Ling Zhang. Multi-Dimensional Classification via Selective Feature Augmentation, In: International Journal of Automation and Computing, in press.
%
%See also costFuncL2, gradFuncL1, soft.

    if nargin<4
        para_setting.lambda1 = 1;
        para_setting.lambda2 = 1;
        para_setting.file_id = 1;
        para_setting.head_str = '   ';
        para_setting.verbose = 1;   
    end
    lambda1 = para_setting.lambda1;
    lambda2 = para_setting.lambda2;
    all_fid = para_setting.file_id;
    head_str = para_setting.head_str;
    verbose = para_setting.verbose;
    
    [num_training,num_features] = size(X_train);
    w = zeros(num_features+1,1);
    X = [ones(num_training,1),X_train];
    y = y_train;
    if num_f_L2<num_features
        max_iter = 50;
    else
        max_iter = 1;
    end
    sign_vec = zeros(max_iter,1);
    for out_iter=1:max_iter
        if verbose
            fprintf(all_fid,[head_str,'   iter=',num2str(out_iter),' begin...\n']); 
        end
        w_old = w;
        %update bias and weights w.r.t. L2 regularization
        if verbose
            fprintf(all_fid,[head_str,'      update bias and weights w.r.t. L2 regularization...\n']); 
        end
        options = optimset('GradObj', 'on', 'Display','off', 'MaxIter', 400);% Set Options
        theta = fminunc(@(t)(costFuncL2(t, w(num_f_L2+2:end), X, y, lambda1, lambda2)), w(1:num_f_L2+1), options);% Optimize
        w(1:num_f_L2+1) = theta;
        %update weights w.r.t. L1 regularization
        if num_f_L2<num_features
            if verbose
                fprintf(all_fid,[head_str,'      update weights w.r.t. L1 regularization...\n']); 
            end
            Lip = sum(sum(X(:,num_f_L2+2:end).^2))/4;%lipschitz constant
            w_tmp =  w(num_f_L2+2:end);
            apg_t_plus1 = 1;
            for L1_iter = 1:max_iter
                apg_t = apg_t_plus1;
                w_l1_old = w(num_f_L2+2:end);%W_{t-1}
                grad_t = gradFuncL1(w(1:num_f_L2+1), w_tmp, X, y);
                u_t = w_tmp - 1/Lip*grad_t;
                w(num_f_L2+2:end) = soft(u_t,lambda2/Lip);%W_{t}
                apg_t_plus1 = (1+sqrt(4*apg_t^2+1))/2;
                w_tmp = w(num_f_L2+2:end)+(apg_t-1)/apg_t_plus1*(w(num_f_L2+2:end)-w_l1_old);
                max_dif_L1 = max(abs(w_l1_old-w(num_f_L2+2:end)));
                if (L1_iter>9)&&(max_dif_L1<0.01)%max_dif_L1<0.01%
                    break;
                end
            end
        end
        y_sign=(((X*w_old).*(X*w))<0);
        sign_vec(out_iter) = sum(y_sign(:));
        w_dif = abs(w_old-w); 
        max_dif = max(w_dif);
        if verbose
            fprintf(all_fid,[head_str,'   iter=',num2str(out_iter),' finish[max_dif=',num2str(max_dif),',#sign=',num2str(sign_vec(out_iter)),']...\n']); 
        end
        if ((out_iter>10)&&(sum(sign_vec(out_iter-4:out_iter))==0)&&(max_dif<0.1))||(max_dif<0.01)
            break;
        end
    end
end