function [ dist_val, dist_idx ] = kNN_distance_matrix( X_train,X_test,Num,max_mat_elements )
    %default parameters setting
	if nargin < 4
		max_mat_elements=1000*1000;%maximum matrix elements
	end
	if nargin < 3
		Num = 8;%Number of nearest neighbors considered
	end
	if nargin < 2
		error('Not enough input parameters!');
	end
%% parameters initializing...	
    num_training = size(X_train,1);%number of training set inst.
    num_testing = size(X_test,1);%number of testing set inst.
    %judge that whether the testing set equals training set (used for training set ifself)
    if num_training==num_testing
        if sum(sum(abs(X_train-X_test)))<1e-3
            the_same_flag = 1;
        else
            the_same_flag = 0;
        end    
    else
        the_same_flag = 0;
    end
    %block_size*num_training <=max_mat_elements
    block_size=floor(max_mat_elements/num_training);
    num_blocks=ceil(num_testing/block_size);
    %initialize outputs
    dist_val = zeros(num_testing,Num);
    dist_idx = zeros(num_testing,Num);
    
%% main loop
    for iter=1:num_blocks
        %determine starting index low & ending index high of this loop
        low=block_size*(iter-1)+1;
        if(iter==num_blocks)
            high=num_testing;
        else
            high=block_size*iter;
        end
        %determine sub-distance matrix
        tmp_data=X_test(low:high,:);
        tmp_size=size(tmp_data,1);
        mat1=concur(sum(X_train.^2,2),tmp_size);
        mat2=concur(sum(tmp_data.^2,2),num_training)';
        tmp_dist_matrix=mat1+mat2-2*X_train*tmp_data';
        tmp_dist_matrix=sqrt(tmp_dist_matrix);
        tmp_dist_matrix=tmp_dist_matrix';
        %distance between instance and itself should be set as positive infinity 
        if the_same_flag
            for i=low:high
                tmp_dist_matrix(i-low+1,i)=realmax;
            end
        end
        for i=low:high
            %sort the distances between instane #i and intances in training set in ascending order
            [temp,index]=sort(tmp_dist_matrix(i-low+1,:));
            dist_val(i,:) = temp(1:Num);%output
            dist_idx(i,:) = index(1:Num);%output
        end
    end
%% the end of fuction
end

