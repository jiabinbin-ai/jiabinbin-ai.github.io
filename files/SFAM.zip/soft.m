function w_out = soft(w_in,lambda)
%soft implements the (element-wise) soft-thresholding function

    w_out = max(w_in-lambda,0) - max(-w_in-lambda,0);
end