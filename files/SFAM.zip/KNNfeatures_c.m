function [ X_train_KNNc, X_test_KNNc ] = KNNfeatures_c( X_train, y_train, X_test, Num )
%KNNfeatures_c generates the continuous version of kNN-augmented features [1] for Multi-dimensional data
%
%	Syntax
%
%       [ X_train_KNNc, X_test_KNNc] = KNNfeatures_c( X_train, y_train, X_test, Num )
%
%	Description
%
%   KNNfeatures_c takes,
%       X_train         - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train         - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test          - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       Num             - Number of nearest neighbors (default 8)
%   and returns,
%       X_train_KNNc    - Augmented features for training examples
%       X_test_KNNc     - Augmented features for testing examples
%
%  [1] B.-B. Jia, M.-L. Zhang. Multi-Dimensional Classification via kNN Feature Augmentation, In: Pattern Recognition, 2020.
%
%See also KNNfeatures_d, SVMfeatures.

%% default parameters setting
if nargin<4
    Num = 8;
end
if nargin<3
    error('Not enough input parameters!');
end

%% Obtain parameters of data sets
num_training = size(X_train,1);%number of training examples
num_dim = size(y_train,2);%number of dimensions(class variables)
num_testing = size(X_test,1);%number of testing examples
C_per_dim = cell(num_dim,1);%class labels in each dimension
num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
for dd=1:num_dim
    temp = y_train(:,dd);
    C_per_dim{dd} = unique(temp);
    num_per_dim(dd) = length(C_per_dim{dd});
end
%% set parameters for continuous kNN-augmented features
upper_limit = 0.5;%upper limit for bias from the number of nearest neighbors
lower_limit = 0;%lower limit for bias from the number of nearest neighbors
knn_score = 1./sqrt(1:Num);%scores for k nearest neighbors
%% Obtain continuous kNN-augmented features for training set
%Obtain kNN Distance Matrix of training data set
[ ~, dist_idx ] = kNN_distance_matrix( X_train,X_train,Num);
%kNN-augmented features
train_aug_features = zeros(num_training,sum(num_per_dim));
for i=1:num_training
    index = dist_idx(i,:);
    idx_base = 0;
    for dd=1:num_dim
        for ll=1:num_per_dim(dd)
            idx_base = idx_base + 1;
            temp_score = 0;%used to compute bias
            temp_num = 0;%number of relevant instances in k nearest neighbors
            for kk=1:Num
                if y_train(index(kk),dd)==C_per_dim{dd}(ll)
                    train_aug_features(i,idx_base)=train_aug_features(i,idx_base)+1;
                    temp_score = temp_score + knn_score(kk);%used to compute bias
                    temp_num = temp_num + 1;%number of relevant instances in k nearest neighbors
                end
            end
            %maximum score for temp_num relevant instances in k nearest neighbors
            max_score = sum(knn_score(1:temp_num));
            %minimum score for temp_num relevant instances in k nearest neighbors
            min_score = sum(knn_score(Num-temp_num+1:Num));
            if min_score~=max_score
                %computing bias
                temp_bias = (temp_score-min_score)/(max_score-min_score)*(upper_limit-lower_limit)+lower_limit;
                %plus bias [lower_limit, upper_limit]
                train_aug_features(i,idx_base) = train_aug_features(i,idx_base) + temp_bias;
            end
        end
    end
end

%% Obtain continuous kNN-augmented features for testing instance
%Obtain kNN Distance Matrix of testing data set
[ ~, dist_idx ] = kNN_distance_matrix( X_train,X_test,Num);
%kNN-augmented features
test_aug_features = zeros(num_testing,sum(num_per_dim));
for i=1:num_testing
    index = dist_idx(i,:);
    idx_base = 0;
    for dd=1:num_dim
        for ll=1:num_per_dim(dd)
            idx_base = idx_base + 1;
            temp_score = 0;%used to compute bias
            temp_num = 0;%number of relevant instances in k nearest neighbors
            for kk=1:Num
                if y_train(index(kk),dd)==C_per_dim{dd}(ll)
                    test_aug_features(i,idx_base)=test_aug_features(i,idx_base)+1;
                    temp_score = temp_score + knn_score(kk);%used to compute bias
                    temp_num = temp_num + 1;%number of relevant instances in k nearest neighbors
                end
            end
            %maximum score for temp_num relevant instances in k nearest neighbors
            max_score = sum(knn_score(1:temp_num));
            %minimum score for temp_num relevant instances in k nearest neighbors
            min_score = sum(knn_score(Num-temp_num+1:Num));
            if min_score~=max_score
                %computing bias
                temp_bias = (temp_score-min_score)/(max_score-min_score)*(upper_limit-lower_limit)+lower_limit;
                %plus bias [lower_limit, upper_limit]
                test_aug_features(i,idx_base) = test_aug_features(i,idx_base) + temp_bias;
            end
        end
    end
end
%% output 
X_train_KNNc = train_aug_features;
X_test_KNNc = test_aug_features;

%% the end of fuction
end

