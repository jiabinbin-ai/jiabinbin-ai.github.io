function [ X_train_SVM, X_test_SVM] = SVMfeatures( X_train, y_train, X_test, gamma, out_sel )
%SVMfeatures generates the maximum margin-augmented features
%
%	Syntax
%
%       [ X_train_SVM, X_test_SVM] = SVMfeatures( X_train, y_train, X_test, gamma, out_sel )
%
%	Description
%
%   SVMfeatures takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       gamma       - trade-off for MSVM (default 1)
%		out_sel		- output selection: 1-[X_orginal,X_augmentation](default), 0-[X_augmentation]
%   and returns,
%       X_train_SVM - training augmented features (output style is upon the out_sel parameter)
%       X_test_SVM  - testing augmented features (output style is upon the out_sel parameter)
%
%N.B.: Please ensure that liblinear package [1] (as attached) is put under the matlab path before envoking the SVMfeatures function.
%
%[1] R.-E. Fan, K.-W. Chang, C.-J. Hsieh, X.-R. Wang, and C.-J. Lin. LIBLINEAR: A library for large linear classification, Journal of Machine Learning Research 9(2008), 1871-1874. Software available at https://www.csie.ntu.edu.tw/~cjlin/liblinear/
%
%See also KNNfeatures_d, KNNfeatures_c.

    % default parameters setting
    if nargin<5
        out_sel = 1;
    end
    if nargin<4
        gamma = 1;
    end
    if nargin<3
        error('Not enough input parameters!');
    end

    [num_training,num_dim] = size(y_train);
    num_testing = size(X_test,1);
    W = [];
    liblinear_setting = ['-s 4 -c ',num2str(gamma),' -B 1 -q'];
    for dd=1:num_dim
        model_dd = train(y_train(:,dd),sparse(X_train),liblinear_setting); 
        W = [W,transpose(model_dd.w)];
    end
    train_aug_features = [X_train,ones(num_training,1)]*W;
    test_aug_features = [X_test,ones(num_testing,1)]*W;
    % output format
    if out_sel == 1
        X_train_SVM = [X_train,train_aug_features];
        X_test_SVM = [X_test,test_aug_features];
    else
        X_train_SVM = train_aug_features;
        X_test_SVM = test_aug_features;
    end

% the end of fuction
end

