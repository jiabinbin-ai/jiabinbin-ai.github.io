function [ X_train_KNNd, X_test_KNNd ] = KNNfeatures_d( X_train, y_train, X_test, Num )
%KNNfeatures_d generates the discrete version of kNN-augmented features [1] for Multi-dimensional data
%
%	Syntax
%
%       [ X_train_KNNd, X_test_KNNd ] = KNNfeatures_d( X_train, y_train, X_test, Num )
%
%	Description
%
%   KNNfeatures_d takes,
%       X_train         - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train         - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test          - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       Num             - Number of nearest neighbors (default 8)
%   and returns,
%       X_train_KNNd    - Augmented features for training examples
%       X_test_KNNd     - Augmented features for testing examples
%
%  [1] B.-B. Jia, M.-L. Zhang. Multi-Dimensional Classification via kNN Feature Augmentation, In: Pattern Recognition, 2020.
%
%See also KNNfeatures_c, SVMfeatures.

%% default parameters setting
if nargin<4
    Num = 8;
end
if nargin<3
    error('Not enough input parameters!');
end

%% Obtain parameters of data sets
num_training = size(X_train,1);%number of training examples
num_dim = size(y_train,2);%number of dimensions(class variables)
num_testing = size(X_test,1);%number of testing examples
C_per_dim = cell(num_dim,1);%class labels in each dimension
num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
for dd=1:num_dim
    temp = y_train(:,dd);
    C_per_dim{dd} = unique(temp);
    num_per_dim(dd) = length(C_per_dim{dd});
end

%% Obtain kNN-augmented features for training instance
%Obtain kNN Distance Matrix of training instance
[ ~, dist_idx ] = kNN_distance_matrix( X_train,X_train,Num);
%kNN-augmented features
train_aug_features = zeros(num_training,sum(num_per_dim));
for i=1:num_training
    index = dist_idx(i,:);
    for kk=1:Num
        idx_base = 0;
        for dd=1:num_dim
            for ll=1:num_per_dim(dd)
                if y_train(index(kk),dd)==C_per_dim{dd}(ll)
                    train_aug_features(i,idx_base+ll)=train_aug_features(i,idx_base+ll)+1;
                end
            end
            idx_base = idx_base + num_per_dim(dd);
        end
    end
end

%% Obtain kNN-augmented features for testing instance
%Obtain kNN Distance Matrix of testing instance
[ ~, dist_idx ] = kNN_distance_matrix( X_train,X_test,Num);
%kNN-augmented features
test_aug_features = zeros(num_testing,sum(num_per_dim));
for i=1:num_testing
    index = dist_idx(i,:);
    for kk=1:Num
        idx_base = 0;
        for dd=1:num_dim
            for ll=1:num_per_dim(dd)
                if y_train(index(kk),dd)==C_per_dim{dd}(ll)
                    test_aug_features(i,idx_base+ll)=test_aug_features(i,idx_base+ll)+1;
                end
            end
            idx_base = idx_base + num_per_dim(dd);
        end
    end
end
%% output
X_train_KNNd = train_aug_features;
X_test_KNNd = test_aug_features;

%% the end of fuction
end

