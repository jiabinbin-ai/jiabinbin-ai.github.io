function [ Eval,y_predict,w_multi ] = SFAM( X_train, y_train, X_test, y_test, X_train_aug, X_test_aug, lambda, write_file )
%SFAM implements the SFAM approach as described in [1]
%Type 'help SFAM' under Matlab prompt for more detailed information about SFAM
%
%	Syntax
%
%       [ Eval,y_predict,w_multi ] = SFAM( X_train, y_train, X_test, y_test, X_train_aug, X_test_aug, lambda, write_file )
%
%	Description
%
%   SFAM takes,
%       X_train     - An mxd array, the ith instance of training instance is stored in X_train(i,:)
%       y_train     - An mxq array, the ith class vector of training instance is stored in y_train(i,:)
%       X_test      - An pxd array, the ith instance of testing instance is stored in X_test(i,:)
%       y_test      - An pxq array, the ith class vector of testing instance is stored in y_test(i,:)
%       X_train_aug - Augmented features for X_train
%       X_test_aug  - Augmented features for X_test
%       lambda      - Trade-off parameter for the classification model in Eq.(1)
%       write_file  - A struct where 
%                       write_file.file_id corresponds to the file identifier (default 1, i.e., output to screen)
%                       write_file.head_str corresponds to the head string (default '   ');
%                       write_file.verbose: 1-outputs, 0-no ouputs  (default 1)
%   and returns,
%       Eval	    - A struct where 
%						Eval.HS correpsonds to the hamming score on testing data as described in [1]
%						Eval.EM correpsonds to the exact match on testing data as described in [1]
%						Eval.SEM correpsonds to the sub-exact match on testing data as described in [1]
%       y_predict	- An pxq array, the predicted class matrix for test instance matrix X_test
%
%  [1] Bin-Bin Jia, Min-Ling Zhang. Multi-Dimensional Classification via Selective Feature Augmentation, In: International Journal of Automation and Computing, in press.
%
%See also MCClassifier.

    %default parameter setting
    if nargin<8
        write_file.file_id = 1;%standard output (the screen)
        write_file.head_str = '   ';
        write_file.verbose = 1;%with outputs
    end
    if nargin<7
        lambda = 1;
    end
    
    all_fid = write_file.file_id;
    head_str = write_file.head_str;
    verbose = write_file.verbose;
    % obtain parameters of data sets
    num_training = size(X_train,1);%number of training examples
    num_features = size(X_train,2);%number of input features
    num_dim = size(y_train,2);%number of dimensions(class variables)
    num_testing = size(X_test,1);%number of testing examples
    C_per_dim = cell(num_dim,1);%class labels in each dimension
    num_per_dim = zeros(num_dim,1);%number of class labels in each dimension
    for dd=1:num_dim
        temp = y_train(:,dd);
        C_per_dim{dd} = unique(temp);
        num_per_dim(dd) = length(C_per_dim{dd});
    end

    %Step II: predictive model induction
    if verbose
        temp_str = [head_str,'Step II: predictive model induction via Binary Relevance...\n'];
        fprintf(all_fid,temp_str);
    end
    X_train_aug = [X_train,X_train_aug];
    X_test_aug = [X_test,X_test_aug];
    y_predict = zeros(size(y_test));
    para_setting.lambda1 = lambda;
    para_setting.lambda2 = lambda;
    para_setting.file_id = all_fid;
    para_setting.head_str = [head_str,'   '];
    para_setting.verbose = verbose;
    w_multi = cell(num_dim,1);
    for dd=1:num_dim
        if verbose
            temp_str = [head_str,'   The (',num2str(dd),'/',num2str(num_dim),') dimension...\n'];
            fprintf(all_fid,temp_str);
        end
        [ y_predict(:,dd),w_multi{dd},~ ] = ...
            MCClassifier(X_test_aug,y_train(:,dd),X_train_aug,num_features,para_setting);
    end
    Eval.HS = sum(sum(y_predict==y_test))/(size(y_test,1)*size(y_test,2));
    Eval.EM = sum(sum((y_predict==y_test),2)==size(y_test,2))/size(y_test,1);
    Eval.SEM = sum(sum((y_predict==y_test),2)>=(size(y_test,2)-1))/size(y_test,1);  
end