%This is an examplar file on how the SFAM program could be used (The main function is "SFAM.m")
%
%Type 'help SFAM' under Matlab prompt for more detailed information
%
%N.B.: Please ensure that liblinear package [1] (as attached) is put under the matlab path before envoking the SFAM function (to generate the maximum margin-augmented features).
%
%[1] R.-E. Fan, K.-W. Chang, C.-J. Hsieh, X.-R. Wang, and C.-J. Lin. LIBLINEAR: A library for large linear classification, Journal of Machine Learning Research 9(2008), 1871-1874. Software available at https://www.csie.ntu.edu.tw/~cjlin/liblinear/

clc;clear;close;
% Load the file containing the necessary inputs for calling the SFAM function
load('sample data.mat'); 

% Step I: augmentation features generation
Num=8;%number of nearest neighbors considered for KNN-augmented features
%(1.1)augmentation features with KNN-discrete version
[X_train_KNN1,X_test_KNN1] = KNNfeatures_d(X_train,y_train,X_test,Num);
for ii=1:size(X_train_KNN1,2)%normalization
    tmp_max = max(X_train_KNN1(:,ii));
    tmp_min = min(X_train_KNN1(:,ii));
    if tmp_max-tmp_min>0
        X_train_KNN1(:,ii) = (X_train_KNN1(:,ii) - tmp_min)/(tmp_max-tmp_min);
        X_test_KNN1(:,ii) = (X_test_KNN1(:,ii) - tmp_min)/(tmp_max-tmp_min);
    end
end
%(1.2)augmentation features with KNN-continous version
[X_train_KNN2,X_test_KNN2] = KNNfeatures_c(X_train,y_train,X_test,Num);
for ii=1:size(X_train_KNN2,2)%normalization
    tmp_max = max(X_train_KNN2(:,ii));
    tmp_min = min(X_train_KNN2(:,ii));
    if tmp_max-tmp_min>0
        X_train_KNN2(:,ii) = (X_train_KNN2(:,ii) - tmp_min)/(tmp_max-tmp_min);
        X_test_KNN2(:,ii) = (X_test_KNN2(:,ii) - tmp_min)/(tmp_max-tmp_min);
    end
end
%(1.3)augmentation features with Multi-class SVM by Crammer and Singer
gamma=1;%trade-off parameter for maximum margin-augmented features
[X_train_SVM, X_test_SVM] = SVMfeatures(X_train,y_train,X_test,gamma,0);
for ii=1:size(X_train_SVM,2)%normalization
    tmp_max = max(X_train_SVM(:,ii));
    tmp_min = min(X_train_SVM(:,ii));
    if tmp_max-tmp_min>0
        X_train_SVM(:,ii) = (X_train_SVM(:,ii) - tmp_min)/(tmp_max-tmp_min);
        X_test_SVM(:,ii) = (X_test_SVM(:,ii) - tmp_min)/(tmp_max-tmp_min);
    end
end
X_train_aug = [X_train_KNN1, X_train_KNN2, X_train_SVM];
X_test_aug = [X_test_KNN1, X_test_KNN2, X_test_SVM];

% Step II: SFAM begins
lambda=1;%trade-off parameter for the classification model in Eq.(1)
write_file.file_id = 1;%output to screen
write_file.head_str = '   ';
write_file.verbose = 1;%with outputs
[ Eval,y_predict ] = SFAM(X_train,y_train,X_test,y_test,X_train_aug,X_test_aug,lambda,write_file);

disp(['HammingScore=',num2str(Eval.HS,'%4.3f'),', ExactMatch=',num2str(Eval.EM,'%4.3f'),', SubExactMatch=',num2str(Eval.SEM,'%4.3f')]);