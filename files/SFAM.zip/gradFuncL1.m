function grad = gradFuncL1(thetaL2, thetaL1, X, y)
%gradFuncL1 computes the gradient of cross-entropy loss for L1 regularization

    theta = [thetaL2;thetaL1];
    h_x = sigmoid(X*theta);
    grad = X(:,length(thetaL2)+1:end)'*(h_x-y);
end