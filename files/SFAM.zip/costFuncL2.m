function [J, grad] = costFuncL2(thetaL2, thetaL1, X, y, lambda1, lambda2)
%costFuncL2 computes the cost and gradient of cross-entropy loss for L2 regularization

    theta = [thetaL2;thetaL1];
    h_x = sigmoid(X*theta);
    tmp_idx = (h_x==1)|(h_x==0);
    if sum(tmp_idx)>0
        h_x(h_x==1) = 0.999999999;
        h_x(h_x==0) = 0.000000001;
    end
	J = (-y'*log(h_x) - (1-y)'*log(1-h_x)) + lambda1*sum(thetaL2(2:end).^2) + lambda2*sum(abs(thetaL1));
    grad = X(:,1:length(thetaL2))'*(h_x-y);
    grad(2:end) = grad(2:end) + 2*lambda1*thetaL2(2:end);%except bias
end